"use client"

import { AdminSidebar } from "@/components/admin-sidebar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { SidebarInset, SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar"
import { Search, Download, RefreshCw, Filter, AlertTriangle, Info, AlertCircle } from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"

const mockLogs = [
  {
    id: 1,
    timestamp: "2024-01-20 15:45:23",
    service: "Video Processing API",
    level: "ERROR",
    message: "Failed to process frame 1250 in video PL-002",
    user: "juan.perez@email.com",
    analysis: "PL-002",
    details:
      "Memory allocation failed during frame processing. Stack trace: ProcessingEngine.processFrame() at line 245",
  },
  {
    id: 2,
    timestamp: "2024-01-20 15:42:15",
    service: "Analytics Service",
    level: "CRITICAL",
    message: "Service crashed during metrics calculation",
    user: null,
    analysis: null,
    details: "Unhandled exception in analytics pipeline. Service restarted automatically.",
  },
  {
    id: 3,
    timestamp: "2024-01-20 15:40:08",
    service: "User Management API",
    level: "INFO",
    message: "User authentication successful",
    user: "maria.garcia@email.com",
    analysis: null,
    details: "User logged in from IP 192.168.1.100",
  },
  {
    id: 4,
    timestamp: "2024-01-20 15:38:45",
    service: "Video Processing API",
    level: "WARNING",
    message: "High memory usage detected",
    user: null,
    analysis: "PL-001",
    details: "Memory usage at 85%. Consider scaling up resources.",
  },
  {
    id: 5,
    timestamp: "2024-01-20 15:35:12",
    service: "Notification Service",
    level: "INFO",
    message: "Email notification sent successfully",
    user: "carlos.lopez@email.com",
    analysis: "PL-003",
    details: "Analysis completion notification sent to user",
  },
  {
    id: 6,
    timestamp: "2024-01-20 15:32:30",
    service: "Analytics Service",
    level: "ERROR",
    message: "Database connection timeout",
    user: null,
    analysis: null,
    details: "Connection to analytics database timed out after 30 seconds",
  },
]

export default function LogsPage() {
  return (
    <SidebarProvider>
      <AdminSidebar />
      <SidebarInset>
        <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4">
          <SidebarTrigger className="-ml-1" />
          <div className="flex flex-1 items-center justify-between">
            <h1 className="text-lg font-semibold">Logs del Sistema</h1>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <RefreshCw className="mr-2 h-4 w-4" />
                Auto-refresh
              </Button>
              <Button variant="outline" size="sm">
                <Download className="mr-2 h-4 w-4" />
                Exportar
              </Button>
              <ThemeToggle />
            </div>
          </div>
        </header>

        <div className="flex flex-1 flex-col gap-4 p-4">
          {/* Log Statistics */}
          <div className="grid gap-4 md:grid-cols-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <Info className="h-4 w-4 text-blue-500" />
                  Info
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">1,247</div>
                <p className="text-xs text-muted-foreground">últimas 24h</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-yellow-500" />
                  Warnings
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">89</div>
                <p className="text-xs text-muted-foreground">últimas 24h</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-red-500" />
                  Errors
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">23</div>
                <p className="text-xs text-muted-foreground">últimas 24h</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-red-600" />
                  Critical
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">3</div>
                <p className="text-xs text-muted-foreground">últimas 24h</p>
              </CardContent>
            </Card>
          </div>

          {/* Filters and Search */}
          <Card>
            <CardHeader>
              <CardTitle>Filtros y Búsqueda</CardTitle>
              <CardDescription>Busca y filtra logs por diferentes criterios</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-5">
                <div className="relative">
                  <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Buscar en logs..." className="pl-8" />
                </div>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Servicio" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los servicios</SelectItem>
                    <SelectItem value="video">Video Processing API</SelectItem>
                    <SelectItem value="user">User Management API</SelectItem>
                    <SelectItem value="analytics">Analytics Service</SelectItem>
                    <SelectItem value="notification">Notification Service</SelectItem>
                  </SelectContent>
                </Select>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Nivel" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos los niveles</SelectItem>
                    <SelectItem value="info">INFO</SelectItem>
                    <SelectItem value="warning">WARNING</SelectItem>
                    <SelectItem value="error">ERROR</SelectItem>
                    <SelectItem value="critical">CRITICAL</SelectItem>
                  </SelectContent>
                </Select>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Período" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1h">Última hora</SelectItem>
                    <SelectItem value="24h">Últimas 24h</SelectItem>
                    <SelectItem value="7d">Últimos 7 días</SelectItem>
                    <SelectItem value="30d">Últimos 30 días</SelectItem>
                  </SelectContent>
                </Select>
                <Button>
                  <Filter className="mr-2 h-4 w-4" />
                  Aplicar Filtros
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Logs Table */}
          <Card>
            <CardHeader>
              <CardTitle>Logs en Tiempo Real</CardTitle>
              <CardDescription>Últimos eventos del sistema ordenados por timestamp</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Timestamp</TableHead>
                    <TableHead>Servicio</TableHead>
                    <TableHead>Nivel</TableHead>
                    <TableHead>Mensaje</TableHead>
                    <TableHead>Usuario</TableHead>
                    <TableHead>Análisis</TableHead>
                    <TableHead>Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockLogs.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell className="font-mono text-xs">{log.timestamp}</TableCell>
                      <TableCell className="text-sm">{log.service}</TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            log.level === "CRITICAL"
                              ? "destructive"
                              : log.level === "ERROR"
                                ? "destructive"
                                : log.level === "WARNING"
                                  ? "secondary"
                                  : "outline"
                          }
                        >
                          {log.level}
                        </Badge>
                      </TableCell>
                      <TableCell className="max-w-md">
                        <div className="truncate">{log.message}</div>
                      </TableCell>
                      <TableCell className="text-sm">
                        {log.user ? (
                          <span className="text-blue-600">{log.user}</span>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell className="text-sm">
                        {log.analysis ? (
                          <Badge variant="outline">{log.analysis}</Badge>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() =>
                            alert(
                              `Detalles del log:\n\nTimestamp: ${log.timestamp}\nServicio: ${log.service}\nNivel: ${log.level}\nMensaje: ${log.message}\nDetalles: ${log.details}`,
                            )
                          }
                        >
                          Ver Detalles
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      </SidebarInset>
    </SidebarProvider>
  )
}
